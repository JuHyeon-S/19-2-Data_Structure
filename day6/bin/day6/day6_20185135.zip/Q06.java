package day6;

public class Q06 {
	public static void main(String []args) {
//		calcStack<String> cc = new calcStack<String>();
//		
//		String s = "81,37,-211,+,15,-,/";
//		double rst = cc.calc(s);
//		System.out.println(rst);
//		
//		
		calcStack<String> cc2 = new calcStack<String>();
		
		String s2 = "20.5,10.2,+,*";
		double rst = cc2.calc(s2);
		System.out.println(rst);
	}
}
